This package can create and parse NTLM authorisation tokens
with all the latest standards such as NTLMv2, Extended Protection
(CBT), message integrity and confidentiality (signing and sealing).


