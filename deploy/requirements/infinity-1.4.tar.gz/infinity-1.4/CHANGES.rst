Changelog
=========

Here you can see the full list of changes between each infinity release.


1.4 (2016-04-01)
----------------

- Added __hash__ method


1.3 (2014-01-10)
----------------

- Made __eq__ return True for inf == float('inf') and -inf == float('-inf')


1.2 (2014-01-09)
----------------

- Added support for __rdiv__, __radd__, __rsub__ and __rmul__ operators
- Added is_infinite utility function
- Added __repr__


1.1 (2014-01-06)
----------------

- Added __rpow__ implementation for infinity


1.0 (2014-01-05)
----------------

- Initial public release
