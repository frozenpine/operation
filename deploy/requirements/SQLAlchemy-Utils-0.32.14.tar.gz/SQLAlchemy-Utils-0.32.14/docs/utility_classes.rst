Utility classes
===============

QueryChain
----------

.. automodule:: sqlalchemy_utils.query_chain

API
---

.. autoclass:: QueryChain
    :members:
